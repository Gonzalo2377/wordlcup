#!/usr/bin/env node
/* ============================================================
   MUNDIAL VALUE — daily robot
   ------------------------------------------------------------
   Calls The Odds API once, keeps only FOOTBALL (1X2), maps it to
   the shape the web reads, runs the SAME model as the site, builds
   the day's accumulators, and writes ../daily.json.

   Run:   ODDS_API_KEY=xxxx node fetch-daily.js
   CI:    see ../../.github/workflows/daily-odds.yml

   Node 18+ (built-in fetch). No external dependencies.
   ============================================================ */
'use strict';
const fs = require('fs');
const path = require('path');

/* ---------------- config (env) ---------------- */
const API_KEY = process.env.ODDS_API_KEY;
// World Cup matches live under 'soccer_fifa_world_cup' (only once books list them).
// Out of season, test with any in-season football key, e.g.:
//   soccer_uefa_champs_league · soccer_spain_la_liga · soccer_conmebol_copa_america
//   soccer_china_superleague  · or 'upcoming' to scan everything (we filter football).
const SPORT   = process.env.ODDS_SPORT   || 'soccer_fifa_world_cup';
const REGIONS = process.env.ODDS_REGIONS || 'eu';   // eu|uk|us|au (comma-sep). Each region = 1 credit.
const MARKET  = 'h2h';                               // match winner (1X2)
// Optional whitelist of bookmakers (base ids, comma-sep), e.g. "bet365,betfair,winamax,williamhill,pinnacle".
const BOOK_WHITELIST = (process.env.ODDS_BOOKS || '').split(',').map(s => s.trim()).filter(Boolean);
const OUT = path.join(__dirname, '..', 'daily.json');

if (!API_KEY) { console.error('✗ Missing ODDS_API_KEY env var'); process.exit(1); }

/* ---------------- national-team database ----------------
   The Odds API gives team NAMES only → map to id / FIFA rank /
   colour / recent form (form feeds the model). Edit freely;
   unknown teams get a safe fallback (rank 55, neutral colour). */
const TEAMS_DB = [
    { id:'arg', name:'Argentina',      code:'ARG', color:'#6cabdd', conf:'CONMEBOL', fifa:1,  form:'WWWWD', aliases:['argentina'] },
    { id:'esp', name:'España',         code:'ESP', color:'#c8102e', conf:'UEFA',     fifa:2,  form:'WWWDW', aliases:['spain','españa','espana'] },
    { id:'fra', name:'Francia',        code:'FRA', color:'#1f3a93', conf:'UEFA',     fifa:3,  form:'WWDWW', aliases:['france','francia'] },
    { id:'eng', name:'Inglaterra',     code:'ENG', color:'#ffffff', conf:'UEFA',     fifa:4,  form:'WDWWD', aliases:['england','inglaterra'] },
    { id:'bra', name:'Brasil',         code:'BRA', color:'#ffd23f', conf:'CONMEBOL', fifa:5,  form:'WDWLW', aliases:['brazil','brasil'] },
    { id:'por', name:'Portugal',       code:'POR', color:'#0aa05a', conf:'UEFA',     fifa:6,  form:'WWLWW', aliases:['portugal'] },
    { id:'ned', name:'Países Bajos',   code:'NED', color:'#ff8a1e', conf:'UEFA',     fifa:7,  form:'WWDLW', aliases:['netherlands','holland','holanda','países bajos','paises bajos'] },
    { id:'bel', name:'Bélgica',        code:'BEL', color:'#e5484d', conf:'UEFA',     fifa:8,  form:'WLWDW', aliases:['belgium','bélgica','belgica'] },
    { id:'ger', name:'Alemania',       code:'GER', color:'#1a1a1a', conf:'UEFA',     fifa:9,  form:'DWWLW', aliases:['germany','alemania'] },
    { id:'cro', name:'Croacia',        code:'CRO', color:'#c8102e', conf:'UEFA',     fifa:10, form:'DWDWL', aliases:['croatia','croacia'] },
    { id:'uru', name:'Uruguay',        code:'URU', color:'#6cabdd', conf:'CONMEBOL', fifa:11, form:'WDWWL', aliases:['uruguay'] },
    { id:'mar', name:'Marruecos',      code:'MAR', color:'#c8102e', conf:'CAF',      fifa:12, form:'WWDWL', aliases:['morocco','marruecos'] },
    { id:'col', name:'Colombia',       code:'COL', color:'#ffd23f', conf:'CONMEBOL', fifa:13, form:'DWWDW', aliases:['colombia'] },
    { id:'ita', name:'Italia',         code:'ITA', color:'#1f5fd6', conf:'UEFA',     fifa:9,  form:'WWDWL', aliases:['italy','italia'] },
    { id:'mex', name:'México',         code:'MEX', color:'#0a7d3c', conf:'CONCACAF', fifa:14, form:'LWDWL', aliases:['mexico','méxico'] },
    { id:'usa', name:'Estados Unidos', code:'USA', color:'#1f5fd6', conf:'CONCACAF', fifa:16, form:'WLWDL', aliases:['usa','united states','estados unidos'] },
    { id:'jpn', name:'Japón',          code:'JPN', color:'#1f3a93', conf:'AFC',      fifa:17, form:'WWLWD', aliases:['japan','japón','japon'] },
    { id:'sen', name:'Senegal',        code:'SEN', color:'#0aa05a', conf:'CAF',      fifa:18, form:'WDWLW', aliases:['senegal'] },
    { id:'sui', name:'Suiza',          code:'SUI', color:'#e5484d', conf:'UEFA',     fifa:19, form:'DWDLW', aliases:['switzerland','suiza'] },
    { id:'den', name:'Dinamarca',      code:'DEN', color:'#c8102e', conf:'UEFA',     fifa:20, form:'WLDWW', aliases:['denmark','dinamarca'] },
    { id:'aut', name:'Austria',        code:'AUT', color:'#e5484d', conf:'UEFA',     fifa:22, form:'WWDLW', aliases:['austria'] },
    { id:'kor', name:'Corea del Sur',  code:'KOR', color:'#1f5fd6', conf:'AFC',      fifa:23, form:'WDLWD', aliases:['south korea','korea republic','corea del sur'] },
    { id:'ecu', name:'Ecuador',        code:'ECU', color:'#ffd23f', conf:'CONMEBOL', fifa:24, form:'DWDWL', aliases:['ecuador'] },
    { id:'ukr', name:'Ucrania',        code:'UKR', color:'#ffd23f', conf:'UEFA',     fifa:25, form:'WLDWD', aliases:['ukraine','ucrania'] },
    { id:'tur', name:'Turquía',        code:'TUR', color:'#c8102e', conf:'UEFA',     fifa:26, form:'WWLDW', aliases:['turkey','turquia','türkiye','turkiye'] },
    { id:'can', name:'Canadá',         code:'CAN', color:'#c8102e', conf:'CONCACAF', fifa:27, form:'WLWDL', aliases:['canada','canadá'] },
    { id:'pol', name:'Polonia',        code:'POL', color:'#e5484d', conf:'UEFA',     fifa:28, form:'LWDWL', aliases:['poland','polonia'] },
    { id:'wal', name:'Gales',          code:'WAL', color:'#c8102e', conf:'UEFA',     fifa:29, form:'DLWDW', aliases:['wales','gales'] },
    { id:'pan', name:'Panamá',         code:'PAN', color:'#c8102e', conf:'CONCACAF', fifa:30, form:'WDLWL', aliases:['panama','panamá'] },
    { id:'sco', name:'Escocia',        code:'SCO', color:'#1f3a93', conf:'UEFA',     fifa:31, form:'WDWLL', aliases:['scotland','escocia'] },
    { id:'nor', name:'Noruega',        code:'NOR', color:'#c8102e', conf:'UEFA',     fifa:32, form:'WWWDL', aliases:['norway','noruega'] },
    { id:'egy', name:'Egipto',         code:'EGY', color:'#c8102e', conf:'CAF',      fifa:33, form:'WDWLW', aliases:['egypt','egipto'] },
    { id:'nga', name:'Nigeria',        code:'NGA', color:'#0aa05a', conf:'CAF',      fifa:34, form:'DWLWD', aliases:['nigeria'] },
    { id:'aus', name:'Australia',      code:'AUS', color:'#ffd23f', conf:'AFC',      fifa:35, form:'WDWLW', aliases:['australia'] },
    { id:'civ', name:'Costa de Marfil',code:'CIV', color:'#ff8a1e', conf:'CAF',      fifa:40, form:'WWDLW', aliases:['ivory coast','cote d\'ivoire','costa de marfil'] },
    { id:'cri', name:'Costa Rica',     code:'CRC', color:'#c8102e', conf:'CONCACAF', fifa:43, form:'LWDLW', aliases:['costa rica'] },
    { id:'qat', name:'Catar',          code:'QAT', color:'#7d1128', conf:'AFC',      fifa:44, form:'WLDWW', aliases:['qatar','catar'] },
    { id:'sau', name:'Arabia Saudí',   code:'KSA', color:'#0aa05a', conf:'AFC',      fifa:58, form:'LDWLW', aliases:['saudi arabia','arabia saudi','arabia saudí'] },
    { id:'irn', name:'Irán',           code:'IRN', color:'#0aa05a', conf:'AFC',      fifa:20, form:'WDWWL', aliases:['iran','irán','ir iran'] },
];
const BOOK_COLORS = {
    bet365:'#0a7d3c', bwin:'#1a1a1a', williamhill:'#1f5fd6', betfair:'#ffb01f', winamax:'#e5484d',
    codere:'#0aa05a', pinnacle:'#3a4660', sport888:'#ff8a1e', unibet:'#0aa05a', marathonbet:'#1f5fd6',
    betclic:'#e5484d', nordicbet:'#1f3a93', betsson:'#ff8a1e', leovegas:'#e5a000', tipico:'#c8102e',
    onexbet:'#1f5fd6', coolbet:'#0aa05a', betonlineag:'#1a1a1a',
};

const norm = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim();
const aliasMap = {};
TEAMS_DB.forEach(t => { aliasMap[norm(t.name)] = t; (t.aliases||[]).forEach(a => aliasMap[norm(a)] = t); });

function resolveTeam(name, sink) {
    const hit = aliasMap[norm(name)];
    if (hit) { sink[hit.id] = { id:hit.id, name:hit.name, code:hit.code, color:hit.color, conf:hit.conf, fifa:hit.fifa, form:hit.form }; return hit.id; }
    const id = norm(name).replace(/[^a-z0-9]/g,'').slice(0,6) || ('t' + Object.keys(sink).length);
    sink[id] = { id, name, code: name.replace(/[^A-Za-z]/g,'').slice(0,3).toUpperCase() || 'TBD', color:'#5a6b8c', conf:'—', fifa:55, form:'' };
    return id;
}

/* normalise regional bookmaker keys to a single brand id (best price kept) */
const REGION = /(_ex)?(_(eu|uk|us|au|fr|de|se|nl|it|es|dk|no|fi|ie|pt|be|ca))+$/;
function baseBook(key){ return (key||'').toLowerCase().replace(REGION,'').replace(/[^a-z0-9]/g,'') || key; }
function bookName(title){ return (title||'').replace(/\s*\(.*\)\s*$/,'').trim(); }
function bookAbbr(name){ return (name||'').replace(/[^A-Za-z0-9]/g,'').slice(0,4).toUpperCase(); }

/* ---------------- the model (ported 1:1 from model.js) -------- */
function ratingFromRank(rank){ return 1500 + 560 * Math.exp(-0.035 * (rank - 1)); }
function formScore(form){ if(!form) return 0; const p={W:3,D:1,L:0}; let s=0,n=0; for(const c of form){ if(p[c]!=null){s+=p[c];n++;} } return n ? ((s/n)-1.5)*28 : 0; }
const _f=[1]; function factorial(n){ if(_f[n]!=null)return _f[n]; let r=_f[_f.length-1]; for(let i=_f.length;i<=n;i++){r*=i;_f[i]=r;} return _f[n]; }
function poisson(k,l){ return Math.exp(-l)*Math.pow(l,k)/factorial(k); }
function dcTau(i,j,lh,la,rho){ if(i===0&&j===0)return 1-lh*la*rho; if(i===0&&j===1)return 1+lh*rho; if(i===1&&j===0)return 1+la*rho; if(i===1&&j===1)return 1-rho; return 1; }
function computeModel(homeId, awayId, teams, opts){
    opts=opts||{}; const H=teams[homeId], A=teams[awayId];
    if(!H||!A) return { home:1/3, draw:1/3, away:1/3 };
    const rH=ratingFromRank(H.fifa)+formScore(H.form);
    const rA=ratingFromRank(A.fifa)+formScore(A.form);
    const homeAdv = opts.neutral===false ? 65 : 16;
    const sup=(rH-rA+homeAdv)/120;
    const avg=(rH+rA)/2;
    let totals=Math.max(2.1,Math.min(3.1, 2.7-(avg-1850)/650));
    const lh=Math.max(0.18,(totals+sup)/2), la=Math.max(0.18,(totals-sup)/2);
    const rho=-0.08, MAX=10; let pH=0,pD=0,pA=0;
    for(let i=0;i<=MAX;i++){ const pi=poisson(i,lh); for(let j=0;j<=MAX;j++){ const p=pi*poisson(j,la)*dcTau(i,j,lh,la,rho); if(i>j)pH+=p; else if(i===j)pD+=p; else pA+=p; } }
    const s=pH+pD+pA||1;
    return { home:pH/s, draw:pD/s, away:pA/s, lambdaH:lh, lambdaA:la, ratingH:rH, ratingA:rA, sup };
}

/* ---------------- value helpers ------------------------------ */
function bestPrice(map){ let best=null; for(const b in map) if(!best||map[b]>best.price) best={book:b,price:map[b]}; return best; }
function marketProbs(m){ const avg=o=>{const v=Object.values(o);return v.reduce((s,x)=>s+1/x,0)/v.length;}; const h=avg(m.odds.home),d=avg(m.odds.draw),a=avg(m.odds.away),s=h+d+a; return {home:h/s,draw:d/s,away:a/s}; }
function matchValue(m){ const mk=marketProbs(m); const outs=['home','draw','away'].map(k=>{ const best=bestPrice(m.odds[k]); return {k,modelP:m.model[k],mktP:mk[k],best,edge:(m.model[k]-mk[k])*100}; }); outs.sort((a,b)=>b.edge-a.edge); const top=outs[0]; return {pick:top,edge:top.edge,positive:top.edge>=2}; }

/* ---------------- API ---------------------------------------- */
async function fetchOdds(){
    const url = `https://api.the-odds-api.com/v4/sports/${SPORT}/odds/?apiKey=${API_KEY}&regions=${REGIONS}&markets=${MARKET}&oddsFormat=decimal`;
    const res = await fetch(url);
    if (!res.ok) throw new Error(`API ${res.status}: ${await res.text()}`);
    console.log('· credits used:', res.headers.get('x-requests-last'), '· remaining:', res.headers.get('x-requests-remaining'));
    return res.json();
}
const fmtGroup = (iso)=> new Date(iso).toLocaleDateString('es-ES',{weekday:'short',day:'2-digit',month:'short',timeZone:'Europe/Madrid'});
const fmtTime  = (iso)=> new Date(iso).toLocaleTimeString('es-ES',{hour:'2-digit',minute:'2-digit',timeZone:'Europe/Madrid'});

/* ---------------- build daily.json --------------------------- */
async function main(){
    const events = await fetchOdds();
    console.log(`· ${events.length} events returned`);

    const TEAMS = {}, BOOKS = {}, MATCHES = [];

    for (const ev of events) {
        if (!/^soccer/.test(ev.sport_key || SPORT)) continue;   // FOOTBALL only

        const homeId = resolveTeam(ev.home_team, TEAMS);
        const awayId = resolveTeam(ev.away_team, TEAMS);
        const odds = { home:{}, draw:{}, away:{} };

        for (const bk of (ev.bookmakers || [])) {
            const id = baseBook(bk.key);
            if (BOOK_WHITELIST.length && !BOOK_WHITELIST.includes(id)) continue;
            const mkt = (bk.markets || []).find(x => x.key === 'h2h');
            if (!mkt) continue;
            BOOKS[id] = BOOKS[id] || { name: bookName(bk.title) || id, abbr: bookAbbr(bookName(bk.title)) || id.slice(0,4).toUpperCase(), color: BOOK_COLORS[id] || '#5a6b8c', url:'#' };
            for (const o of mkt.outcomes) {
                let slot = null;
                if (o.name === ev.home_team) slot = 'home';
                else if (o.name === ev.away_team) slot = 'away';
                else if (/draw|empate|tie|x/i.test(o.name)) slot = 'draw';
                if (!slot) continue;
                // keep the BEST (highest) price across a brand's regional variants
                if (!odds[slot][id] || o.price > odds[slot][id]) odds[slot][id] = o.price;
            }
        }
        if (!Object.keys(odds.home).length || !Object.keys(odds.draw).length || !Object.keys(odds.away).length) continue;

        MATCHES.push({ id: ev.id || `${homeId}-${awayId}`, group: fmtGroup(ev.commence_time), time: fmtTime(ev.commence_time), home: homeId, away: awayId, odds });
    }

    MATCHES.forEach(m => { m.model = computeModel(m.home, m.away, TEAMS, { neutral:true }); });
    const valued = MATCHES.map(m => ({ m, v: matchValue(m) })).filter(x => x.v.positive).sort((a,b)=>b.v.pick.modelP - a.v.pick.modelP);

    // ---- auto-build the day's accumulators ----
    const label = (m,k) => k==='draw' ? 'Empate' : (k==='home' ? TEAMS[m.home].name : TEAMS[m.away].name);
    const legOf = (x) => ({ match:`${TEAMS[x.m.home].name} – ${TEAMS[x.m.away].name}`, pick:label(x.m,x.v.pick.k), odd:+x.v.pick.best.price.toFixed(2), book:x.v.pick.best.book });
    const confOf = (arr) => Math.round(arr.reduce((p,x)=>p*x.v.pick.modelP,1)*100);
    const COMBOS = [];
    if (valued.length >= 2) COMBOS.push({ id:'c1', tier:'single', conf:confOf(valued.slice(0,3)), name:'Combinada del Día', legs:valued.slice(0,3).map(legOf) });
    const byEdge = [...valued].sort((a,b)=>b.v.edge-a.v.edge);
    if (byEdge.length >= 2) COMBOS.push({ id:'c2', tier:'all', conf:confOf(byEdge.slice(0,3)), name:'Combinada Valor', legs:byEdge.slice(0,3).map(legOf) });
    if (valued.length >= 4) COMBOS.push({ id:'c3', tier:'all', conf:confOf(valued.slice(0,4)), name:'Combinada Alto Valor', legs:valued.slice(0,4).map(legOf) });

    // ---- preserve the existing track record (auto-settling = Scores API; see SETUP) ----
    let RECORD = [];
    try { RECORD = JSON.parse(fs.readFileSync(OUT,'utf8')).RECORD || []; } catch (e) {}

    const daily = {
        meta: { updatedAt:new Date().toISOString(), source:'the-odds-api', sport:SPORT, regions:REGIONS, market:MARKET, matches:MATCHES.length, valuePicks:valued.length, books:Object.keys(BOOKS).length },
        TEAMS, BOOKS, MATCHES, COMBOS, RECORD,
    };
    fs.writeFileSync(OUT, JSON.stringify(daily, null, 2));
    console.log(`✓ wrote ${OUT}\n  ${MATCHES.length} football matches · ${valued.length} value picks · ${Object.keys(BOOKS).length} books · ${COMBOS.length} accas`);
    if (!MATCHES.length) console.log('  (no football matches for this sport key right now — see SETUP to test with an in-season league)');
}

main().catch(e => { console.error('✗', e.message); process.exit(1); });
